include(Resources.id("mtrsteamloco:scripts/display_helper.js"));
importPackage(java.awt);
importPackage(java.awt.geom);
importPackage(java.io);
importPackage(java.net);
importPackage(java.util);

const melody = new ConfigResponder.TextField("melody", ComponentUtil.translatable("メロディ音声名(名前空間(minecraft:など)も含む)"), "");
const tojime = new ConfigResponder.TextField("tojime", ComponentUtil.translatable("戸閉音声名"), "");
const melody_type = new ConfigResponder.CycleToggle("melody_type", ComponentUtil.translatable("メロディタイプ"), 0, ["標準", "立川式"]);

function create(ctx, state, blockEntity) {
    state.rate = new RateLimit(0.2);
    state.clickCount = 0;
    state.sound = null;
    state.soundTojime = null;
    state.isPlaying = false;

    // 操作要求フラグ
    state.playMelodyRequested = false;
    state.stopMelodyRequested = false;
    state.playTojimeRequested = false;
    state.isTachikawaType = false;
    state.loopOffRequested = false;

    blockEntity.setShape("5,3,13,11,13,16");
}

function use(ctx, state, blockEntity, player) {
    state.clickCount++;

    // 初期化はここで一回だけ
    if (state.sound == null) {
        let melodyId = blockEntity.getCustomConfig("melody");
        state.sound = new TickableSound(Resources.id(melodyId), SoundHelper.getSoundSource("MASTER"));
        state.sound.setData(2.0, 1.0, blockEntity.getWorldPosVector3f());
        state.sound.setLooping(true);
        state.sound.setDelay(0);
    }
    if (state.soundTojime == null) {
        let tojimeId = blockEntity.getCustomConfig("tojime");
        state.soundTojime = new TickableSound(Resources.id(tojimeId), SoundHelper.getSoundSource("MASTER"));
        state.soundTojime.setData(2.0, 1.0, blockEntity.getWorldPosVector3f());
        state.soundTojime.setLooping(false);
        state.soundTojime.setDelay(1.5);
    }

    if (state.clickCount >= 2) {
        state.isTachikawaType = (blockEntity.getCustomConfig("melody_type") == 1);

        if (state.isTachikawaType) {
            // 立川式：ループを切るだけ（停止はしない）
            //state.stopMelodyRequested = false;
            //state.playMelodyRequested = false;
            // フラグでループ切りをrequest
            state.loopOffRequested = true;
            state.playTojimeRequested = true;
        } else {
            // その他：メロディ停止して戸閉放送再生
            state.stopMelodyRequested = true;
            state.playTojimeRequested = true;
        }
        state.clickCount = 0;
    } else if (state.clickCount === 1) {
        state.playMelodyRequested = true;
    }
}

function render(ctx, state, blockEntity) {
    blockEntity.registerCustomConfig(melody);
    blockEntity.registerCustomConfig(tojime);
    blockEntity.registerCustomConfig(melody_type);

    if (!state.rate.shouldUpdate()) return;

    if (state.playMelodyRequested) {
        if (!state.isPlaying) {
            SoundHelper.play(state.sound);
            state.isPlaying = true;
        }
        state.playMelodyRequested = false;
    }

    if (state.loopOffRequested) {
        if (state.isPlaying) {
            state.sound.setLooping(false);
        }
        state.loopOffRequested = false;
    }

    if (state.stopMelodyRequested) {
        if (state.isPlaying) {
            SoundHelper.stop(state.sound);
            state.isPlaying = false;
        }
        state.stopMelodyRequested = false;
    }

    if (state.playTojimeRequested) {
        SoundHelper.play(state.soundTojime);
        state.playTojimeRequested = false;
    }
}

function dispose(ctx, state, blockEntity) {
    if (state.sound) {
        SoundHelper.stop(state.sound);
        state.sound = null;
    }
    if (state.soundTojime) {
        SoundHelper.stop(state.soundTojime);
        state.soundTojime = null;
    }
}
