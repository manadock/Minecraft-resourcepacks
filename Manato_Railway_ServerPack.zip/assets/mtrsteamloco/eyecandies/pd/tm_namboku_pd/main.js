importPackage(java.awt);
importPackage(java.awt.geom);
importPackage(java.io);
importPackage(java.net);
importPackage(java.util);
importPackage(java.lang);
importPackage(java.util.concurrent);

function create(ctx, state, entity) {
  state.rate = new RateLimit(0.1);
  state.doorR = ModelManager.loadRawModel(Resources.manager(), Resources.id("mtrsteamloco:eyecandies/pd/tm_namboku_pd/tm_namboku_pd_dr.obj"), null);
  state.doorL = ModelManager.loadRawModel(Resources.manager(), Resources.id("mtrsteamloco:eyecandies/pd/tm_namboku_pd/tm_namboku_pd_dl.obj"), null);
  state.dmhdoorR = new DynamicModelHolder();
  state.dmhdoorL = new DynamicModelHolder();

  state.dmhdoorR.uploadLater(state.doorR);
  state.dmhdoorL.uploadLater(state.doorL);

  state.soundTime = -1;
  state.doorTargetLast = entity.doorTarget;
}

function dispose(ctx, state, entity) {
  state.dmhdoorR.close();
  state.dmhdoorL.close();
}

function render(ctx, state, entity) {
  if (state.rate.shouldUpdate()) {
    if (entity.doorTarget != state.doorTargetLast) {
      if (Date.now() > state.soundTime + 1000) {
        let soundId = Resources.id("mtrsteamloco:tm_g_pd")
        let k = new TickableSound(soundId);
        k.setData(1, 1, entity.getWorldPosVector3f());
        let delay = entity.doorTarget ? 0 : 20;
        SoundHelper.play(k, delay);
        state.soundTime = Date.now();
      }
    }
    state.doorTargetLast = entity.doorTarget;
  }
  //ドア動作
  let doorValue = entity.doorValue * 1.6;
  if (entity.doorValue > 0.75) {
    doorValue = 1.2;
  }

  let matR = new Matrices();
  matR.pushPose();
  matR.translate(doorValue, 0, 0);
  ctx.drawModel(state.dmhdoorR.getUploadedModel(), matR);
  matR.popPose();

  let matL = new Matrices();
  matL.pushPose();
  matL.translate(-doorValue, 0, 0);
  ctx.drawModel(state.dmhdoorL.getUploadedModel(), matL);
  matL.popPose();

}

function use(ctx, state, entity, player) {

}